package Utilities;

public class Intro {
    public static void show() {
        String text = "AUTOMATED PARKING SYSTEM";
        for (char c : text.toCharArray()) {
            System.out.print(c);
            try { Thread.sleep(30); } catch (Exception e) {} 
        }
        System.out.println("\nLOADING SYSTEM COMPONENT MODULES...");
        
        

        for (int i = 0; i <= 100; i += 20) {
            System.out.print("[" + i + "%]\r");
            try { Thread.sleep(1000); } catch (Exception e) {}
        }
        System.out.println("\nSYSTEM ONLINE & READY!\n");
        System.out.println("""                        
        	    
        	                                           █████╗ ██╗   ██╗████████╗ ██████╗      ██████╗  █████╗ ██████╗ ██╗  ██╗      ███████╗██╗   ██╗███████╗
        	                                          ██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗     ██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝      ██╔════╝╚██╗ ██╔╝██╔════╝
        	                                          ███████║██║   ██║   ██║   ██║   ██║     ██████╔╝███████║██████╔╝█████╔╝       ███████╗ ╚████╔╝ ███████╗
        	                                          ██╔══██║██║   ██║   ██║   ██║   ██║     ██╔═══╝ ██╔══██║██╔══██╗██╔═██╗       ╚════██║  ╚██╔╝  ╚════██║
        	                                          ██║  ██║╚██████╔╝   ██║   ╚██████╔╝     ██║     ██║  ██║██║  ██║██║  ██╗      ███████║   ██║   ███████║
        	                                          ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝      ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝      ╚══════╝   ╚═╝   ╚══════╝

        	                                                                          Welcome to the Automated Parking System
        	                                                               ----------------------------------------------------------------
        	                                                               """
        		
        		                                                                                                                                               );
        

        
    }
}