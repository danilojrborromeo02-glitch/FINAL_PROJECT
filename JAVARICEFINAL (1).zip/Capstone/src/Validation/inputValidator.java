package Validation;

public class inputValidator {
    public static boolean validatePlate(String plate) {
        // Accepts pattern variations like AAA1234 or AAA 123
        return plate.matches("[A-Z]{3} ?[0-9]{3,4}");
    }
}