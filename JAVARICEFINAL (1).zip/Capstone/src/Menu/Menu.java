package Menu;

public class Menu {

    // Method to center text based on console width
    public static String centerText(String text, int width) {
        int padding = (width - text.length()) / 2;

        if (padding < 0) return text;

        return " ".repeat(padding) + text;
    }

    public static void show() {

        int width = 110; // Adjust depending on your console fullscreen size

        String[] menu = {

" █████╗ ██╗   ██╗████████╗ ██████╗ ███╗   ███╗ █████╗ ████████╗███████╗██████╗ ",
"██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗████╗ ████║██╔══██╗╚══██╔══╝██╔════╝██╔══██╗",
"███████║██║   ██║   ██║   ██║   ██║██╔████╔██║███████║   ██║   █████╗  ██║  ██║",
"██╔══██║██║   ██║   ██║   ██║   ██║██║╚██╔╝██║██╔══██║   ██║   ██╔══╝  ██║  ██║",
"██║  ██║╚██████╔╝   ██║   ╚██████╔╝██║ ╚═╝ ██║██║  ██║   ██║   ███████╗██████╔╝",
"╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═════╝ ",
"",
          "██████╗  █████╗ ██████╗ ██╗  ██╗██╗███╗   ██╗ ██████╗ ",
          "██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝██║████╗  ██║██╔════╝ ",
          "██████╔╝███████║██████╔╝█████╔╝ ██║██╔██╗ ██║██║  ███╗",
          "██╔═══╝ ██╔══██║██╔══██╗██╔═██╗ ██║██║╚██╗██║██║   ██║",
          "██║     ██║  ██║██║  ██║██║  ██╗██║██║ ╚████║╚██████╔╝",
          "╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ",
          "",

      "╔══════════════════════════════════════════════════════════════╗",
      "║              SMART • SECURE • EFFICIENT PARKING             ║",
      "╚══════════════════════════════════════════════════════════════╝",
      "",
              "╔════════════════════════════════════════════╗",
              "║         PARKING MANAGEMENT SYSTEM          ║",
              "╠════════════════════════════════════════════╣",
              "║  1. 🚗 Vehicle Entry                       ║",
              "║  2. 🧾 Vehicle Exit & Billing              ║",
              "║  3. 🅿️  Parking Grid Map                   ║",
              "║  4. 📋 View Activity Logs                  ║",
              "║  5. 🔒 Log Out                             ║",
              "║  6. ❌ Exit System                         ║",
              "╠════════════════════════════════════════════╣",
              "║        Select an option (1 - 6)            ║",
              "╚════════════════════════════════════════════╝",
              ""
        };

        // Print everything centered
        for (String line : menu) {
            System.out.println(centerText(line, width));
        }

        System.out.print(centerText("➜ Enter choice: ", width));
    }
}