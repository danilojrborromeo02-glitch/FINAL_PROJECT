package Main;

import Billing.*;
import File.FileHandler;
import Login.LoginSystem;
import Menu.Menu;
import Parking.ParkingManager;
import Validation.inputValidator;
import Vehicles.VehicleType;
import Utilities.Colors;
import Utilities.Intro;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class main {

    public static void main(String[] args) {

        Intro.show();
        Scanner sc = new Scanner(System.in);

        while (true) { // LOGIN LOOP
        	
            LoginSystem login = new LoginSystem();

            if (!login.login()) {
            	 Intro.show();
                System.out.println(Colors.RED + "Access Denied: Invalid Credentials." + Colors.RESET);
                continue;
            }

            System.out.println(Colors.GREEN + "Access Granted." + Colors.RESET);

            boolean loggedIn = true;          
            Menu.show();
            while (loggedIn) { // MENU LOOP

              
                System.out.print("Choice: ");
                
                int c = 0;

                if (sc.hasNextInt()) {
                    c = sc.nextInt();
                    sc.nextLine();
                } else {
                    sc.nextLine();
                    System.out.println("Invalid input numeric type expected.");
                    continue;
                }

                switch (c) {

                case 1 -> { // Vehicle Entry

                    if (ParkingManager.isFull()) {
                        System.out.println(Colors.RED + "PARKING FULL!" + Colors.RESET);
                        break;
                    }

                    while (true) {

                        // ===================== PLATE NUMBER =====================
                        System.out.print("Enter Plate Number: ");
                        String plate = sc.nextLine().toUpperCase().trim();

                        if (!inputValidator.validatePlate(plate)) {
                            System.out.println(Colors.RED + "Invalid Vehicle Plate Format." + Colors.RESET);
                            continue;
                        }

                        // ===================== COLOR MENU =====================
                        System.out.println("====================================================================================");
                        System.out.println("= Vehicle Color Options:                                                           ");
                        System.out.println("= [1] " + Colors.BLACK + "Black" + Colors.RESET +
                                           "  [2] " + Colors.WHITE + "White" + Colors.RESET +
                                           "  [3] " + Colors.BLUE + "Blue" + Colors.RESET +
                                           "  [4] " + Colors.RED + "Red" + Colors.RESET);
                        System.out.println("= [5] " + Colors.YELLOW + "Yellow" + Colors.RESET +
                                           "  [6] Other");
                        System.out.println("= [0] BACK                                                                          ");
                        System.out.println("====================================================================================");
                        System.out.print("Select Color Option: ");
                        int col = sc.nextInt();
                        sc.nextLine();

                        // BACK TO PLATE NUMBER
                        if (col == 0) {
                            System.out.println("Returning to Plate Number...");
                            continue;
                        }

                        String color;

                        switch (col) {

                            case 1 -> color = "Black";
                            case 2 -> color = "White";
                            case 3 -> color = "Blue";
                            case 4 -> color = "Red";
                            case 5 -> color = "Yellow";
                            case 6 -> {
                                System.out.print("Enter Custom Vehicle Color: ");
                                color = sc.nextLine().trim();

                                if (color.isEmpty()) {
                                    System.out.println(Colors.RED + "WHAT Color?." + Colors.RESET);
                                    continue;
                                }
                            }

                            default -> {
                                System.out.println(Colors.RED + "Invalid Color!." + Colors.RESET);
                                continue;
                            }
                        }

                        // ===================== VEHICLE TYPE =====================
                        System.out.println("===================================================================================");
                        System.out.println("= Vehicle Classification: [1] Car [2] Motorcycle [3] 3-Wheel [4] Electric Vehicle =");
                        System.out.println("= [0] BACK                                                                        =");
                        System.out.println("===================================================================================");

                        System.out.print("Select Type: ");
                        int t = sc.nextInt();
                        sc.nextLine();

                        // BACK TO PLATE NUMBER
                        if (t == 0) {
                            System.out.println("Returning to Plate Number...");
                            continue;
                        }

                        VehicleType type = switch (t) {
                            case 2 -> VehicleType.MOTORCYCLE;
                            case 3 -> VehicleType.THREE_WHEEL;
                            case 4 -> VehicleType.E_VEHICLE;
                            default -> VehicleType.CAR;
                        };

                        // ===================== SAVE =====================
                        long inTime = System.currentTimeMillis();
                        int ticket = ParkingManager.generateTicket();

                        FileHandler.write(
                                "C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\vehicles.txt",
                                plate + "," + color + "," + type + "," + inTime + "," + ticket);

                        ParkingManager.addSlot(plate);

                        System.out.println( "\n===================================================");
                        System.out.println(Colors.GREEN + "\n--- RECORD SAVED ---" +  Colors.RESET);
                        System.out.println("====================================================");
                        System.out.println("ASSIGNED TICKET ID: " + ticket);
                        Menu.show();
                        break; // EXIT LOOP AFTER SUCCESS
                    }
                }

                    case 2 -> { // Vehicle Exit And Discount Options
                    	
                    	

                        System.out.print("Enter Exit Plate Number: ");
             
                        
                        String exitPlate = sc.nextLine().toUpperCase().trim();

                        String color = FileHandler.getColor(exitPlate);
                        VehicleType vt = FileHandler.getType(exitPlate);

                        if (vt == null) {
                            System.out.println(Colors.RED + "Vehicle Records Not Found." + Colors.RESET);
                            break;
                        }

                        long outTime = System.currentTimeMillis();

                        long structuralTimeSimulation = 1000L * 60 * 150;
                        long inTimeSimulated = outTime - structuralTimeSimulation;

                        BillingSystem billableHours = new BillingSystem();

                        double fee = billableHours.calculateFee(
                                vt,
                                inTimeSimulated,
                                outTime);

                        System.out.print(
                                "Apply Special Discount? [1] PWD [2] Senior Citizen [0] None: ");

                        int dt = sc.nextInt();
                        sc.nextLine();
                        
                        billableHours.setDiscountType(dt);

                        double discount = billableHours.applyDiscount(fee);
                        double total = fee - discount;

                        int exitTicket = ParkingManager.generateTicket();

                        Receipt.print(
                        	    exitTicket,
                        	    exitPlate,
                        	    color,
                        	    vt,
                        	    fee,
                        	    discount,
                        	    total);
                        
                        
                        Menu.show();

                        FileHandler.write(
                                "C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\transactions.txt",
                                exitPlate + ", Paid: ₱" + total);
                        

                        ParkingManager.removeSlot(exitPlate);
                        
                    }

                    case 3 -> ParkingManager.showGrid();

                    case 4 -> {

                        System.out.println("\n=== REGISTRATION DATA PROFILE LOGS ===");
                        FileHandler.displayFile("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\vehicles.txt");

                        System.out.println("\n=== FINANCIAL BALANCES TRANSACTIONS ===");
                        FileHandler.displayFile("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\transactions.txt");
                    }

                    case 5 -> { // LOG OUT

                        System.out.println(
                                Colors.YELLOW + "Logging Out..." + Colors.RESET);

                        loggedIn = false; 	
                    }

                    case 6 -> { // TERMINATE PROGRAM

                        System.out.println(
                                Colors.RED + "Systems Shutdown thank you (:D) " + Colors.RESET);	

                        System.exit(0); 
                    }

                    default -> System.out.println("Invalid selection option context.");
                }
            }
        }
    }
}