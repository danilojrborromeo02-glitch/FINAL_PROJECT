package Parking;

import java.io.*;
import java.util.Random;

import Menu.Menu;

public class ParkingManager {
    private static final int MAX = 50;

    public static int countSlots() {
        int c = 0;
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\slots.txt"))) {
            while (br.readLine() != null) c++;
        } catch (Exception e) { /* File empty or missing */ }
        return c;
    }

    public static boolean isFull() {
        return countSlots() >= MAX;
    }

    public static int generateTicket() {
        return new Random().nextInt(90000) + 10000;
    }

    public static void addSlot(String plate) {
        try (FileWriter fw = new FileWriter("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\slots.txt", true)) {
            fw.write(plate + "\n");
        } catch (Exception e) {
            System.out.println("Error storing operational slot.");
        }
    }

    public static void removeSlot(String plate) {

        File input = new File(
            "C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\slots.txt");

        File temp = new File(
            "C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\temp.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(input));
             FileWriter fw = new FileWriter(temp)) {

            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().equalsIgnoreCase(plate.trim())) {
                    fw.write(line + "\n");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        input.delete();
        temp.renameTo(input);
    }
    
    public static void showGrid() {
    	
        System.out.println("\n=== PARKING GRID (50 SLOTS) ===");
        int used = countSlots();
        System.out.println("Occupied: " + used + " / " + MAX + " Slots\n");

        for (int i = 1; i <= MAX; i++) {
        	
            if (i <= used) {
                System.out.print("[_X] ");
            } else {
                System.out.printf("[%02d] ", i);
              
            
            } 
         
            if (i % 10 == 0) {
                System.out.println();
            } 
        }
        Menu.show();
        
        System.out.println();
    }
}