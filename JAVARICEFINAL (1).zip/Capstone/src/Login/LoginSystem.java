package Login;

import java.util.Scanner;
import Utilities.Colors;

public class LoginSystem {
    public boolean login() {
        Scanner sc = new Scanner(System.in);
        
        while (true) {
            System.out.println("                                       ===== ADMIN PORTAL =====");
            System.out.print("                                               User: ");
            String u = sc.nextLine();

            System.out.print("                                               Pass: ");
            String p = sc.nextLine();

            // Check credentials
            if (u.equals("admin") && p.equals("1234")) {
                return true; // Breaks the loop and returns true to main.java
            } else {
                System.out.println(Colors.RED + "\nInvalid username or password. Please try again.\n" + Colors.RESET);
            }
        }
    }
}