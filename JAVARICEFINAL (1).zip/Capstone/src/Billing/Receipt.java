package Billing;

import Vehicles.VehicleType;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import Utilities.Colors;
public class Receipt {

	public static void print(
			int ticket, String plate,String color,VehicleType type,double fee,double discount,double total) {
		
		String colorDisplay;

		switch (color.toUpperCase()) {
		    case "BLACK" -> colorDisplay = Colors.BLACK + color + Colors.RESET;
		    case "WHITE" -> colorDisplay = Colors.WHITE + color + Colors.RESET;
		    case "BLUE" -> colorDisplay = Colors.BLUE + color + Colors.RESET;
		    case "RED" -> colorDisplay = Colors.RED + color + Colors.RESET;
		    case "YELLOW" -> colorDisplay = Colors.YELLOW + color + Colors.RESET;
		    case "CYAN" -> colorDisplay = Colors.CYAN + color + Colors.RESET;
		    case "GREEN" -> colorDisplay = Colors.GREEN + color + Colors.RESET;
		    default -> colorDisplay = color;
		}

        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        System.out.println("\n========== RECEIPT ==========");
        System.out.println("Time Out : " + now.format(formatter));
        System.out.println("Ticket    : " + ticket);
        System.out.println("Plate     : " + plate);
        System.out.println("Color     : " + colorDisplay);
        System.out.println("Type      : " + type);
        System.out.printf("Fee       : ₱%.2f%n", fee);
        System.out.printf("Discount  : ₱%.2f%n", discount);
        System.out.printf("Total     : ₱%.2f%n", total);
        System.out.println("=============================");
    }
}