package Billing;

public interface Discountable {
    double applyDiscount(double fee);
}