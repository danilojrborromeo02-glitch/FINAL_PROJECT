package Billing;

import Vehicles.VehicleType;

public class BillingSystem implements Discountable {
    private int discountType = 0; // 0 = None, 1 = PWD, 2 = Senior

    public void setDiscountType(int type) {
        this.discountType = type;
    }

    public double calculateFee(VehicleType type, long inTime, long outTime) {
        long durationMs = outTime - inTime;
        if (durationMs <= 0) return 0.0;

        // Convert milliseconds to hours
        double hours = (double) durationMs / (1000 * 60 * 60);

        // First 15 minutes free rule (15 minutes = 0.25 hours)
        if (hours <= 0.25) {
            return 0.0;
        }
        
        double billableHours = hours - 0.25;
        double rate = switch (type) {
            case THREE_WHEEL -> 30.0;
            case MOTORCYCLE -> 50.0;
            case CAR -> 75.0;
            case E_VEHICLE -> 30.0; // Assume free base parking or minor alternative
        };

        return billableHours * rate;
    }

    @Override
    public double applyDiscount(double fee) {
        if (discountType == 1 || discountType == 2) {
            return fee * 0.20; // 20% Discount for Senior / PWD
        }
        return 0.0;
    }
}