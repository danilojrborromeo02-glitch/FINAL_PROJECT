package File;

import java.io.*;
import Vehicles.VehicleType;

public class FileHandler {

    static {
        // Automatically set up database environment directories and empty files if there is no database named FOlder!
    	
        try {
            File dir = new File("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles");
            if (!dir.exists()) dir.mkdirs();

            String[] files = {"vehicles.txt", "slots.txt", "transactions.txt"};
            for (String f : files) {
                File file = new File(dir, f);
                if (!file.exists()) file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("Initialization Error creating database files.");
        }
    }

    public static void write(String filePath, String data) {
        try (FileWriter fw = new FileWriter(filePath, true)) {
            fw.write(data + "\n");
        } catch (Exception e) {
            System.out.println("Error writing to file: " + filePath);
        }
    }
    
    //File Reader for check if there are records of Name Plates for Entry and Exit

    public static VehicleType getType(String plate) {
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\vehicles.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");
                if (d.length >= 3 && d[0].equalsIgnoreCase(plate)) {
                    return VehicleType.valueOf(d[2].toUpperCase());
                }
            }
        } catch (Exception e) {
            System.out.println("Error reading vehicle records.");
        }
        return null;
    }

    public static void displayFile(String path) {
        File file = new File(path);
        if (!file.exists() || file.length() == 0) {
            System.out.println("[No records available yet]");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (Exception e) {
            System.out.println("Error reading file: " + path);
        }
    }
    public static String getColor(String plate) {
        try (BufferedReader br = new BufferedReader(
                new FileReader("C:\\Users\\cabal\\Downloads\\Capybara\\Capstone\\src\\TxtFiles\\vehicles.txt"))) {

            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");

                if (d.length >= 2 && d[0].equalsIgnoreCase(plate)) {
                    return d[1];
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return "Unknown";
    }
}