package Vehicles;

public enum VehicleType {
    CAR,
    MOTORCYCLE,
    THREE_WHEEL,
    E_VEHICLE
}